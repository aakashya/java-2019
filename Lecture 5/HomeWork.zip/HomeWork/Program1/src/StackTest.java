00public class StackTest
{ 
    public static void main(String args[]) 
    { 
        Stack s = new Stack();
        System.out.println("Choose any one option:");
        System.out.println("1. push()");
        System.out.println("2. pop()");
        System.out.println("3. isEmpty()");
        System.out.println("4. isFull()");
        System.out.println("5. spaceLeft()");
        
        
    } 
}
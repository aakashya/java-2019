public class Address
{
	String firstLine;
	String secondLine;
	long pinCode;
	Address(String fLine,String sLine,long pc)
	{
		this.firstLine=fLine;
		this.secondLine=sLine;
		this.pinCode=pc;
	}	

}